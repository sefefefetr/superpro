add your bot on https://discord.gg/GjfHmXAYTn for emoji access 
don't forgot to give me credit